# SURVIVALCRAFT 64 — Beta 0.2

## Qué intenta hacer esta versión
- Crear una isla de bloques 3D muy pequeña.
- Dibujar cubos con colores planos: césped, tierra y piedra.
- Mover la cámara con el stick analógico.
- Girar la cámara con C-izquierda/C-derecha y mirar arriba/abajo con C-arriba/C-abajo.
- Reiniciar la cámara con START.

## Tecnología
Esta versión usa libdragon estable y dibuja triángulos RDPQ. La transformación 3D y la proyección se calculan en la CPU. No usa Tiny3D ni un microcódigo 3D externo. Es una estrategia conservadora para intentar reducir dependencias especiales del emulador.

## Estado real
Este paquete contiene **código fuente**, no una ROM `.z64`. No se ha compilado ni ejecutado todavía. La compatibilidad de `xbox64.xex` con ROMs homebrew compiladas con libdragon debe comprobarse en la consola. La documentación de libdragon recomienda emuladores modernos y precisos para validar homebrew, así que no podemos garantizar que Salvia 360 ejecute esta ROM sin una prueba.

## Compilar
Requiere libdragon instalado en una computadora compatible:
https://libdragon.dev/

Configura `N64_INST` y ejecuta `make` en esta carpeta. El Makefile usa el `n64.mk` del SDK.

## Prueba en Salvia 360
Cuando exista una ROM `.z64` compilada, coloca una copia en la carpeta `roms/n64/` de Salvia 360 (o en la carpeta equivalente de ROMs de tu USB), actualiza/escanea la lista de juegos y ejecútala con el core de Nintendo 64.

## Limitaciones de Beta 0.2
- No hay colisiones ni gravedad.
- No hay personaje visible: la cámara representa al jugador.
- Todavía no se rompen ni colocan bloques.
- La ordenación de caras es una técnica simple de pintor; en escenas complejas puede producir errores de profundidad.
- El terreno es fijo y diminuto.

## Siguiente versión
Beta 0.3: colisiones, gravedad sencilla, selección de bloque y retícula central.
