/*
 * SURVIVALCRAFT 64 - Beta 0.2
 * Isla de bloques 3D de bajo coste.
 *
 * Renderizado: proyeccion 3D por CPU + triangulos RDPQ.
 * No usa Tiny3D ni microcodigo 3D externo.
 * SDK: libdragon (trunk/stable).
 *
 * Estado: codigo fuente preparado; aun debe compilarse y probarse
 * en el emulador xbox64.xex de Salvia 360.
 */
#include <libdragon.h>
#include <math.h>
#include <stdlib.h>
#include <stdbool.h>

#define SCREEN_W 320
#define SCREEN_H 240
#define BLOCK_MAX 40
#define FACE_MAX (BLOCK_MAX * 6)
#define PI 3.14159265358979323846f

typedef struct { float x, y, z; } Vec3;
typedef struct { Vec3 p[4]; color_t color; float depth; } Face;
typedef struct { int x, z, h; int type; } Block;

typedef struct {
    float x, y, z;
    float yaw, pitch;
} Camera;

static Block world[BLOCK_MAX];
static int world_count = 0;
static Face faces[FACE_MAX];
static int face_count = 0;
static Camera cam = { 2.5f, 2.15f, -5.7f, 0.0f, 0.20f };

static Vec3 v3(float x, float y, float z) {
    Vec3 v = {x, y, z}; return v;
}

static void add_block(int x, int z, int h, int type) {
    if (world_count >= BLOCK_MAX) return;
    world[world_count++] = (Block){x, z, h, type};
}

static void create_island(void) {
    world_count = 0;
    /* Isla compacta de 5 x 5 bloques. */
    for (int z = 0; z < 5; z++) {
        for (int x = 0; x < 5; x++) {
            int edge = (x == 0 || x == 4 || z == 0 || z == 4);
            int h = 0;
            if ((x == 2 && z == 2) || (x == 2 && z == 1)) h = 1;
            add_block(x, z, h, edge ? 1 : 0);
        }
    }
    /* Pequeno afloramiento de piedra. */
    add_block(3, 2, 1, 2);
    add_block(3, 2, 2, 2);
}

static Vec3 rotate_to_camera(Vec3 p) {
    float dx = p.x - cam.x;
    float dy = p.y - cam.y;
    float dz = p.z - cam.z;
    float cy = cosf(cam.yaw), sy = sinf(cam.yaw);
    float cp = cosf(cam.pitch), sp = sinf(cam.pitch);

    float x1 = dx * cy - dz * sy;
    float z1 = dx * sy + dz * cy;
    float y2 = dy * cp - z1 * sp;
    float z2 = dy * sp + z1 * cp;
    return v3(x1, y2, z2);
}

static bool project(Vec3 p, float *sx, float *sy, float *depth) {
    Vec3 q = rotate_to_camera(p);
    if (q.z < 0.18f) return false;
    const float focal = 118.0f;
    *sx = (SCREEN_W * 0.5f) + (q.x * focal / q.z);
    *sy = (SCREEN_H * 0.5f) - (q.y * focal / q.z);
    *depth = q.z;
    return true;
}

static void push_face(Vec3 a, Vec3 b, Vec3 c, Vec3 d, color_t color) {
    if (face_count >= FACE_MAX) return;
    Vec3 center = v3((a.x+b.x+c.x+d.x)*0.25f,
                     (a.y+b.y+c.y+d.y)*0.25f,
                     (a.z+b.z+c.z+d.z)*0.25f);
    Vec3 view = rotate_to_camera(center);
    Face *f = &faces[face_count++];
    f->p[0]=a; f->p[1]=b; f->p[2]=c; f->p[3]=d;
    f->color=color; f->depth=view.z;
}

static void build_faces(void) {
    face_count = 0;
    for (int i = 0; i < world_count; i++) {
        Block b = world[i];
        float x=(float)b.x, y=(float)b.h, z=(float)b.z;
        color_t top = b.type == 2 ? RGBA32(125,130,140,255) : RGBA32(75,175,65,255);
        color_t side1 = b.type == 2 ? RGBA32(90,95,105,255) : RGBA32(105,75,45,255);
        color_t side2 = b.type == 2 ? RGBA32(105,110,120,255) : RGBA32(125,88,52,255);
        color_t side3 = b.type == 2 ? RGBA32(80,85,95,255) : RGBA32(90,65,40,255);
        color_t bottom = RGBA32(75,50,32,255);

        /* Cada cubo tiene seis caras; se dibujan de atras hacia delante. */
        push_face(v3(x,y+1,z), v3(x+1,y+1,z), v3(x+1,y+1,z+1), v3(x,y+1,z+1), top);
        push_face(v3(x,y,z), v3(x,y,z+1), v3(x+1,y,z+1), v3(x+1,y,z), bottom);
        push_face(v3(x,y,z), v3(x+1,y,z), v3(x+1,y+1,z), v3(x,y+1,z), side1);
        push_face(v3(x+1,y,z), v3(x+1,y,z+1), v3(x+1,y+1,z+1), v3(x+1,y+1,z), side2);
        push_face(v3(x+1,y,z+1), v3(x,y,z+1), v3(x,y+1,z+1), v3(x+1,y+1,z+1), side3);
        push_face(v3(x,y,z+1), v3(x,y,z), v3(x,y+1,z), v3(x,y+1,z+1), side1);
    }
}

static int compare_faces(const void *a, const void *b) {
    const Face *fa = (const Face*)a;
    const Face *fb = (const Face*)b;
    if (fa->depth < fb->depth) return 1;
    if (fa->depth > fb->depth) return -1;
    return 0;
}

static void draw_face(const Face *f) {
    float v[4][3];
    for (int i=0; i<4; i++) {
        float sx, sy, dep;
        if (!project(f->p[i], &sx, &sy, &dep)) return;
        v[i][0]=sx; v[i][1]=sy; v[i][2]=dep;
    }

    rdpq_set_prim_color(f->color);
    rdpq_triangle(&TRIFMT_FILL, v[0], v[1], v[2]);
    rdpq_triangle(&TRIFMT_FILL, v[0], v[2], v[3]);
}

static void render_world(void) {
    build_faces();
    qsort(faces, face_count, sizeof(Face), compare_faces);

    for (int i=0; i<face_count; i++) {
        draw_face(&faces[i]);
    }
}

static void update_camera(void) {
    joypad_poll();
    joypad_inputs_t in = joypad_get_inputs(JOYPAD_PORT_1);
    joypad_buttons_t pressed = joypad_get_buttons_pressed(JOYPAD_PORT_1);

    float forward = (float)in.stick_y / 90.0f;
    float strafe  = (float)in.stick_x / 110.0f;
    float speed = 0.075f;
    float sy = sinf(cam.yaw), cy = cosf(cam.yaw);

    cam.x += (sy * forward + cy * strafe) * speed;
    cam.z += (cy * forward - sy * strafe) * speed;

    if (in.btn.c_left) cam.yaw -= 0.035f;
    if (in.btn.c_right) cam.yaw += 0.035f;
    if (in.btn.c_up) cam.pitch += 0.025f;
    if (in.btn.c_down) cam.pitch -= 0.025f;

    if (cam.pitch > 0.65f) cam.pitch = 0.65f;
    if (cam.pitch < -0.45f) cam.pitch = -0.45f;

    if (pressed.start) {
        cam.x=2.5f; cam.y=2.15f; cam.z=-5.7f;
        cam.yaw=0.0f; cam.pitch=0.20f;
    }
}

int main(void) {
    display_init(RESOLUTION_320x240, DEPTH_16_BPP, 2, GAMMA_NONE, FILTERS_RESAMPLE);
    rdpq_init();
    joypad_init();
    create_island();

    while (1) {
        update_camera();

        surface_t *disp = display_get();
        rdpq_attach(disp, NULL);
        rdpq_set_mode_standard();
        rdpq_mode_combiner(RDPQ_COMBINER_FLAT);
        rdpq_clear(RGBA32(105, 165, 220, 255));

        render_world();

        rdpq_detach();
        display_show(disp);
    }
    return 0;
}
